import '../assets/css/Footer.css'

function Footer() {
    return (
      <footer className="Footer">
        Copyright 2022. JDEX. All Rights Reserved.
      </footer>
    );
}
  
export default Footer;